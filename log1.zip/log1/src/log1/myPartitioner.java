package log1;

import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Partitioner;

public class myPartitioner extends Partitioner<Text, Text> {

	@Override
	public int getPartition(Text arg0, Text arg1, int arg2) {
		String input = arg0.toString();
		if(input.equals("[ERROR]"))
			return 0;
		else if(input.equals("[TRACE]"))
			return 1;
		else if(input.equals("[DEBUG]"))
			return 2;
		else 
			return 3;
	}

}
