package log1;

import java.io.IOException;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;

public class myLog1 {

	public static void main(String[] args) throws IOException, ClassNotFoundException, InterruptedException {
		Configuration conf = new Configuration();
		Job j = new Job(conf,"Log 1");
		j.setJarByClass(myLog1.class);
		j.setMapperClass(myMapper.class);
		j.setReducerClass(myReducer.class);
		j.setPartitionerClass(myPartitioner.class);
		j.setNumReduceTasks(4);
		j.setMapOutputKeyClass(Text.class);
		j.setMapOutputValueClass(Text.class);
		
		FileInputFormat.addInputPath(j, new Path(args[0]));
		FileOutputFormat.setOutputPath(j, new Path(args[1]));
		
		System.exit(j.waitForCompletion(true)?0:1);
		
		
	}

}
