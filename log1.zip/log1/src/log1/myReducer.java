package log1;

import java.io.IOException;

import org.apache.hadoop.io.NullWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Reducer;

public class myReducer extends Reducer<Text,Text,Text,NullWritable>{
	public void reduce(Text rInKey,Iterable<Text> rInVal,Context con) throws IOException, InterruptedException{
		for(Text val:rInVal)
			con.write(val, null);
	}

}
