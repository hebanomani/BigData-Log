package log2;

import java.io.IOException;

import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Reducer;

public class myReducer extends Reducer<Text, Text, Text, IntWritable> {
	public void reduce(Text rInpKey, Iterable<Text> rInpVal, Context c) throws IOException, InterruptedException{
		int count = 0;
		for(Text val: rInpVal){
			count++;
		}
		Text rOutKey= new Text(rInpKey +" log is ");
		c.write(rOutKey, new IntWritable(count));
	}

}
