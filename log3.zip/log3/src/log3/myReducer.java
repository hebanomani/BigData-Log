package log3;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import org.apache.hadoop.io.NullWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Reducer;

public class myReducer extends Reducer<Text, Text, NullWritable, Text>{
	HashMap<String, Integer> hm = new HashMap<>();
	HashMap<Integer,String> hm2= new HashMap<>();
	int count =0;
	public void reduce(Text rInpKey, Iterable<Text> rInpVal, Context c) throws IOException, InterruptedException{
		for(Text each: rInpVal){
			String eachStr=each.toString();
			String[] eachWithInStr= eachStr.split(" ");
			hm.put(eachWithInStr[2], ++count);
			}
		
		for(Map.Entry m: hm.entrySet()){
			Integer key= (Integer) m.getValue();
			hm2.put(key, (String)m.getKey());
		}
		}
	
	public void cleanup(Context c) throws IOException, InterruptedException{
		Map.Entry<Integer,String> entry=hm2.entrySet().iterator().next();
		 Integer key= entry.getKey();
		 String value=entry.getValue();
		Text rOutVal= new Text("Module " +value+" has maximum error log of " +key);
		c.write(null, rOutVal);
		
	}
	}
